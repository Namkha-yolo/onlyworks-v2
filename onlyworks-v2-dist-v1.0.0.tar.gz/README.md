# OnlyWorks v2 - Production Release v1.0.0

## 🎯 What's Included

This is the production-ready distribution of OnlyWorks v2 with all the latest features and improvements.

### 📦 Package Contents
- `main.js` - Main Electron application
- `renderer.js` - Frontend React application
- `preload.js` - Electron preload script
- `overlay.js` - Screen overlay functionality
- `index.html` - Main application window
- `overlay.html` - Overlay window
- `assets/` - Application assets (images, icons)
- `package.json` - Application manifest
- `DEPLOYMENT.md` - Detailed setup instructions
- `RELEASE_NOTES.md` - Complete changelog and features

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Start the Application
```bash
npm start
```

### 3. Setup Backend (Required)
The application requires a backend server. Follow the instructions in `DEPLOYMENT.md` to set up the backend from the `onlyworks-backend-server` repository.

## ⚡ New Features in v1.0.0

- **🌐 Global Activity Monitoring** - Track activity across all applications
- **🎯 Intelligent Scoring** - Automatic productivity and focus scores
- **📊 Adaptive Analysis** - Faster insights with less data required
- **🔧 Enhanced Reliability** - Better error handling and session management

## 📖 Documentation

- **Setup Guide**: See `DEPLOYMENT.md` for complete installation instructions
- **Feature Overview**: Check `RELEASE_NOTES.md` for detailed feature descriptions
- **Architecture**: Backend setup required from separate repository

## 🔗 Related Repositories

- **Backend Server**: [onlyworks-backend-server](https://github.com/Namkha-yolo/onlyworks-backend-server)
- **Frontend Source**: [onlyworks-v2](https://github.com/Namkha-yolo/onlyworks-v2)

## 🛠️ System Requirements

- **Node.js** 18 or higher
- **Operating System**: macOS 10.14+, Windows 10+, or Linux Ubuntu 18.04+
- **Permissions**: Accessibility permissions required for global monitoring
- **Database**: PostgreSQL for backend storage

## 📞 Support

If you encounter any issues:

1. Check `DEPLOYMENT.md` for troubleshooting steps
2. Review `RELEASE_NOTES.md` for known issues
3. Report bugs on the appropriate GitHub repository

## 🔐 Privacy Note

OnlyWorks v2 includes global activity monitoring features. These require system permissions and are designed with privacy in mind:

- All data is stored locally by default
- Screenshots are processed locally unless cloud sync is explicitly enabled
- Global monitoring can be disabled at any time
- No sensitive data is transmitted without user consent

---

**Version**: 1.0.0
**Release Date**: November 2024
**License**: See LICENSE file

Happy productivity tracking! 🚀